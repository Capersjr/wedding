# jam icons
Jam icons is a set of icons designed for web projects, illustrations, print projects, etc. Shipped in both font &amp; svg versions. Licensed under MIT. Twitter: @michaelampr

### Complete icons list
You can see the complete icons list on http://jam-icons.com 

### Need more icons?
Just ask :) 
If you need specific icons that are not in the set, do not hesitate to create an issue. I'll do by best to complete the set.

### Changelog
Jam icons is following the Semantic Versioning (http://semver.org/) with the MAJOR.MINOR.PATCH format.
- V1.0.0 - First release with 422 icons

### Licence
This project is licensed under MIT (https://opensource.org/licenses/MIT)
